package Modelo;

public class Carrito {

}
